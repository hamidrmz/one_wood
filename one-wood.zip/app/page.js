export default function Home() {
  return (
    <div>
      <section style={{padding:"80px 20px", textAlign:"center"}}>
        <h1 style={{fontSize:"50px", color:"#C9A46A"}}>ONE WOOD</h1>
        <p>طراحی و اجرای کابینت و دکوراسیون داخلی مدرن در ارومیه</p>
        <p style={{color:"#aaa"}}>Custom Cabinetry & Interior Design</p>
      </section>

      <section style={{padding:"40px 20px"}}>
        <h2 style={{color:"#C9A46A"}}>خدمات</h2>
        <ul>
          <li>کابینت آشپزخانه</li>
          <li>کمد دیواری</li>
          <li>تی‌وی وال</li>
          <li>کتابخانه</li>
          <li>پارتیشن</li>
        </ul>
      </section>

      <section style={{padding:"40px 20px"}}>
        <h2 style={{color:"#C9A46A"}}>تماس</h2>
        <p>09147233274</p>
        <p>Urmia</p>
        <p>one_wood_cabinet</p>
      </section>
    </div>
  )
}
