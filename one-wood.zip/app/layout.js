export const metadata = {
  title: "One Wood",
  description: "Custom Cabinetry & Interior Design"
}

export default function RootLayout({ children }) {
  return (
    <html lang="fa">
      <body style={{margin:0, backgroundColor:"#121212", color:"#fff", fontFamily:"sans-serif"}}>
        {children}
      </body>
    </html>
  )
}
